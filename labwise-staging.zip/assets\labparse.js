/* LabWise - in-browser lab-report text parser (Task 1 prototype).
   Pure functions, no network, no storage. Input: plain text (from PDF text layer,
   OCR, or paste). Output: candidate rows {name, value, unit, low, high, ...}.
   Synthetic data only during the prototype phase. */
(function (global) {
  'use strict';

  // Canonical markers. Aliases are matched case-insensitively, longest first.
  // "units" = units commonly seen for this marker (used only to flag surprises).
  var MARKERS = [
    { key: 'hemoglobin', name: 'Hemoglobin', aliases: ['hemoglobin', 'haemoglobin', 'hgb', 'hb'], units: ['g/L', 'g/dL'] },
    { key: 'hematocrit', name: 'Hematocrit', aliases: ['hematocrit', 'haematocrit', 'hct'], units: ['L/L', '%'] },
    { key: 'rbc', name: 'Red blood cells (RBC)', aliases: ['rbc count', 'red blood cell count', 'red blood cells', 'erythrocytes', 'rbc'], units: ['x10*12/L', '10^12/L', '10*12/L', 'M/uL'] },
    { key: 'wbc', name: 'White blood cells (WBC)', aliases: ['wbc count', 'white blood cell count', 'white blood cells', 'leukocytes', 'leucocytes', 'wbc'], units: ['x10*9/L', '10^9/L', '10*9/L', 'K/uL'] },
    { key: 'platelets', name: 'Platelets', aliases: ['platelet count', 'platelets', 'plt'], units: ['x10*9/L', '10^9/L', '10*9/L', 'K/uL'] },
    { key: 'mcv', name: 'MCV', aliases: ['mean corpuscular volume', 'mean cell volume', 'mcv'], units: ['fL'] },
    { key: 'mch', name: 'MCH', aliases: ['mean corpuscular hemoglobin', 'mch'], units: ['pg'] },
    { key: 'mchc', name: 'MCHC', aliases: ['mchc'], units: ['g/L', 'g/dL'] },
    { key: 'rdw', name: 'RDW', aliases: ['red cell distribution width', 'rdw-cv', 'rdw'], units: ['%'] },
    { key: 'neutrophils', name: 'Neutrophils', aliases: ['neutrophils', 'neutrophil', 'neut'], units: ['x10*9/L', '10^9/L', '%'] },
    { key: 'lymphocytes', name: 'Lymphocytes', aliases: ['lymphocytes', 'lymphocyte', 'lymph'], units: ['x10*9/L', '10^9/L', '%'] },
    { key: 'monocytes', name: 'Monocytes', aliases: ['monocytes', 'monocyte', 'mono'], units: ['x10*9/L', '10^9/L', '%'] },
    { key: 'eosinophils', name: 'Eosinophils', aliases: ['eosinophils', 'eosinophil', 'eos'], units: ['x10*9/L', '10^9/L', '%'] },
    { key: 'basophils', name: 'Basophils', aliases: ['basophils', 'basophil', 'baso'], units: ['x10*9/L', '10^9/L', '%'] },
    { key: 'glucose', name: 'Glucose (fasting)', aliases: ['glucose fasting', 'fasting glucose', 'glucose, fasting', 'fasting plasma glucose', 'glucose random', 'glucose'], units: ['mmol/L', 'mg/dL'] },
    { key: 'hba1c', name: 'Hemoglobin A1c', aliases: ['hemoglobin a1c', 'haemoglobin a1c', 'glycated hemoglobin', 'hba1c', 'hb a1c', 'a1c'], units: ['%', 'mmol/mol'] },
    { key: 'creatinine', name: 'Creatinine', aliases: ['creatinine', 'creat'], units: ['umol/L', 'µmol/L', 'μmol/L', 'mg/dL'] },
    { key: 'egfr', name: 'eGFR', aliases: ['estimated gfr', 'egfr', 'gfr'], units: ['mL/min/1.73m2', 'mL/min/1.73m²', 'mL/min/1.73 m2', 'mL/min'] },
    { key: 'urea', name: 'Urea (BUN)', aliases: ['blood urea nitrogen', 'urea', 'bun'], units: ['mmol/L', 'mg/dL'] },
    { key: 'sodium', name: 'Sodium', aliases: ['sodium', 'na'], units: ['mmol/L'] },
    { key: 'potassium', name: 'Potassium', aliases: ['potassium', 'k'], units: ['mmol/L'] },
    { key: 'chloride', name: 'Chloride', aliases: ['chloride', 'cl'], units: ['mmol/L'] },
    { key: 'calcium', name: 'Calcium', aliases: ['calcium', 'ca'], units: ['mmol/L', 'mg/dL'] },
    { key: 'magnesium', name: 'Magnesium', aliases: ['magnesium', 'mg'], units: ['mmol/L', 'mg/dL'] },
    { key: 'phosphate', name: 'Phosphate', aliases: ['phosphate', 'phosphorus'], units: ['mmol/L', 'mg/dL'] },
    { key: 'chol', name: 'Total cholesterol', aliases: ['total cholesterol', 'cholesterol total', 'cholesterol, total', 'cholesterol'], units: ['mmol/L', 'mg/dL'] },
    { key: 'ldl', name: 'LDL cholesterol', aliases: ['ldl cholesterol', 'ldl-cholesterol', 'ldl-c', 'ldl'], units: ['mmol/L', 'mg/dL'] },
    { key: 'hdl', name: 'HDL cholesterol', aliases: ['hdl cholesterol', 'hdl-cholesterol', 'hdl-c', 'hdl'], units: ['mmol/L', 'mg/dL'] },
    { key: 'nonhdl', name: 'Non-HDL cholesterol', aliases: ['non-hdl cholesterol', 'non hdl cholesterol', 'non-hdl-c', 'non-hdl'], units: ['mmol/L', 'mg/dL'] },
    { key: 'tg', name: 'Triglycerides', aliases: ['triglycerides', 'triglyceride', 'tg'], units: ['mmol/L', 'mg/dL'] },
    { key: 'alt', name: 'ALT', aliases: ['alanine aminotransferase', 'alt', 'sgpt'], units: ['U/L'] },
    { key: 'ast', name: 'AST', aliases: ['aspartate aminotransferase', 'ast', 'sgot'], units: ['U/L'] },
    { key: 'alp', name: 'ALP', aliases: ['alkaline phosphatase', 'alp'], units: ['U/L'] },
    { key: 'ggt', name: 'GGT', aliases: ['gamma-glutamyl transferase', 'gamma gt', 'ggt'], units: ['U/L'] },
    { key: 'bili', name: 'Bilirubin (total)', aliases: ['bilirubin total', 'total bilirubin', 'bilirubin, total', 'bilirubin'], units: ['umol/L', 'µmol/L', 'μmol/L', 'mg/dL'] },
    { key: 'albumin', name: 'Albumin', aliases: ['albumin'], units: ['g/L', 'g/dL'] },
    { key: 'protein', name: 'Total protein', aliases: ['total protein', 'protein total', 'protein, total'], units: ['g/L', 'g/dL'] },
    { key: 'tsh', name: 'TSH', aliases: ['thyroid stimulating hormone', 'thyrotropin', 'tsh'], units: ['mIU/L', 'mU/L', 'uIU/mL', 'µIU/mL'] },
    { key: 'ft4', name: 'Free T4', aliases: ['free thyroxine', 'free t4', 't4 free', 't4, free', 'ft4'], units: ['pmol/L', 'ng/dL'] },
    { key: 'ft3', name: 'Free T3', aliases: ['free t3', 't3 free', 't3, free', 'ft3'], units: ['pmol/L', 'pg/mL'] },
    { key: 'ferritin', name: 'Ferritin', aliases: ['ferritin'], units: ['ug/L', 'µg/L', 'μg/L', 'ng/mL'] },
    { key: 'iron', name: 'Iron', aliases: ['serum iron', 'iron'], units: ['umol/L', 'µmol/L', 'μmol/L', 'ug/dL'] },
    { key: 'tibc', name: 'TIBC', aliases: ['total iron binding capacity', 'tibc'], units: ['umol/L', 'µmol/L', 'μmol/L', 'ug/dL'] },
    { key: 'tsat', name: 'Transferrin saturation', aliases: ['transferrin saturation', 'iron saturation', 'tsat'], units: ['%'] },
    { key: 'b12', name: 'Vitamin B12', aliases: ['vitamin b12', 'vitamin b-12', 'cobalamin', 'b12'], units: ['pmol/L', 'pg/mL'] },
    { key: 'folate', name: 'Folate', aliases: ['folic acid', 'folate'], units: ['nmol/L', 'ng/mL'] },
    { key: 'vitd', name: 'Vitamin D (25-OH)', aliases: ['25-hydroxyvitamin d', '25-oh vitamin d', '25 oh vitamin d', 'vitamin d 25-hydroxy', 'vitamin d, 25-hydroxy', 'vitamin d3', 'vitamin d'], units: ['nmol/L', 'ng/mL'] },
    { key: 'crp', name: 'CRP', aliases: ['high sensitivity crp', 'high-sensitivity crp', 'c-reactive protein', 'hs-crp', 'hscrp', 'crp'], units: ['mg/L'] },
    { key: 'urate', name: 'Uric acid', aliases: ['uric acid', 'urate'], units: ['umol/L', 'µmol/L', 'μmol/L', 'mg/dL'] },
    { key: 'psa', name: 'PSA', aliases: ['prostate specific antigen', 'psa total', 'psa'], units: ['ug/L', 'µg/L', 'μg/L', 'ng/mL'] },
    { key: 'insulin', name: 'Insulin', aliases: ['insulin'], units: ['pmol/L', 'uIU/mL', 'µIU/mL'] },
    { key: 'cortisol', name: 'Cortisol', aliases: ['cortisol'], units: ['nmol/L', 'ug/dL'] },
    { key: 'testosterone', name: 'Testosterone', aliases: ['testosterone total', 'total testosterone', 'testosterone'], units: ['nmol/L', 'ng/dL'] },
    { key: 'estradiol', name: 'Estradiol', aliases: ['estradiol', 'oestradiol', 'e2'], units: ['pmol/L', 'pg/mL'] }
  ];

  // Lines that may carry personal data. They are dropped BEFORE parsing and never shown.
  var PII_RE = /\b(patient|name|dob|date of birth|birth|health card|health ?#|ohip|ramq|msp|address|phone|tel\b|fax|email|postal|sex\b|gender|age\b|physician|doctor|dr\.|ordered by|requisition|accession|specimen ?#|mrn|client ?#)/i;
  // Dates are stripped from lines (not needed, and never shown). Dots are excluded so "4.0-11.0" is not mistaken for a date.
  var DATE_RE = /\b\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4}\b|\b\d{4}[\/\-]\d{1,2}[\/\-]\d{1,2}\b|\b(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\.? \d{1,2},? \d{4}\b|\b\d{1,2}:\d{2}(?::\d{2})?\b/gi;
  var REAL_UNIT_RE = /[\/%]|^(fL|pg|mmol|nmol|pmol|umol|µmol|μmol|g|mg|ug|µg|IU|U|mIU|mU|kPa|s|sec|min|ratio|index)$/i;

  var NUM = '[<>]?\\s*\\d+(?:[.,]\\d+)?';
  var VALUE_RE = new RegExp('^\\s*([<>]?)\\s*(\\d+(?:[.,]\\d+)?)(?![\\d.,]*[\\/\\-\\u2013\\u2014])');
  var FLAG_RE = /^\s*(HH|LL|H|L|A|\*|High|Low|Abn)(?=\s|$)/i;
  var UNIT_RE = /^\s*((?:x\s?)?10\s?[\^*]\s?\d+\s?\/\s?[A-Za-z]+|[A-Za-zµμ%][A-Za-zµμ%0-9^*\/\.\-²]*)/;
  var RANGE_RE = /(\d+(?:[.,]\d+)?)\s*(?:-|–|—|to|–|—)\s*(\d+(?:[.,]\d+)?)/;
  var ONE_SIDED_RE = /([<>]\s?=?)\s*(\d+(?:[.,]\d+)?)/;
  var UNIT_STOP = /^(to|and|or|of|ref|reference|range|normal|h|l|hh|ll|a)$/i;

  var ALIAS_INDEX = [];
  MARKERS.forEach(function (m) {
    m.aliases.forEach(function (a) {
      ALIAS_INDEX.push({ alias: a, len: a.length, marker: m });
    });
  });
  ALIAS_INDEX.sort(function (a, b) { return b.len - a.len; });

  function esc(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
  ALIAS_INDEX.forEach(function (e) {
    var body = esc(e.alias).replace(/\s+/g, '[\\s,]*');
    e.startRe = new RegExp('^[\\s\\-\\u2022\\*#:]*' + body + '(?![a-z0-9])', 'i');
    e.anyRe = e.len >= 3 ? new RegExp('(?:^|[^a-z0-9])' + body + '(?![a-z0-9])', 'i') : null;
  });

  function toNum(s) {
    if (s == null) return null;
    var n = parseFloat(String(s).replace(',', '.'));
    return isNaN(n) ? null : n;
  }

  function normaliseLine(s) {
    return s
      .replace(/[ \t]+/g, ' ')
      .replace(/[−‐‑‒]/g, '-')
      .replace(/\s{2,}/g, '  ')
      .trim();
  }

  function normaliseUnit(u) {
    if (!u) return '';
    u = u.replace(/\s+/g, '').replace(/μ/g, 'µ');
    u = u.replace(/^x?10\^(\d+)\/L$/i, 'x10*$1/L').replace(/^x?10\*(\d+)\/L$/i, 'x10*$1/L');
    if (/^umol\/l$/i.test(u)) u = 'µmol/L';
    if (/^ug\/l$/i.test(u)) u = 'µg/L';
    if (/^mmol\/l$/i.test(u)) u = 'mmol/L';
    if (/^g\/l$/i.test(u)) u = 'g/L';
    if (/^u\/l$/i.test(u)) u = 'U/L';
    if (/^miu\/l$/i.test(u)) u = 'mIU/L';
    if (/^pmol\/l$/i.test(u)) u = 'pmol/L';
    if (/^nmol\/l$/i.test(u)) u = 'nmol/L';
    if (/^mg\/l$/i.test(u)) u = 'mg/L';
    if (/^mg\/dl$/i.test(u)) u = 'mg/dL';
    if (/^fl$/i.test(u)) u = 'fL';
    if (/^l\/l$/i.test(u)) u = 'L/L';
    return u;
  }

  function unitExpected(marker, unit) {
    if (!marker || !unit) return true;
    var u = unit.replace(/µ/g, 'u').toLowerCase();
    return marker.units.some(function (x) { return x.replace(/µ|μ/g, 'u').toLowerCase() === u; });
  }

  // Parse the text that follows a marker name: value, flag, unit, range.
  function parseTail(tail) {
    var out = { value: null, prefix: '', flag: '', unit: '', low: null, high: null };
    tail = tail.replace(/^\s*\([^)]*\)/, '').replace(/^[\s:=\-–]+/, '');
    var m = VALUE_RE.exec(tail);
    if (!m) return out;
    out.prefix = m[1] || '';
    out.value = toNum(m[2]);
    tail = tail.slice(m[0].length);

    var f = FLAG_RE.exec(tail);
    if (f) { out.flag = f[1].toUpperCase(); tail = tail.slice(f[0].length); }

    var u = UNIT_RE.exec(tail);
    if (u && !UNIT_STOP.test(u[1])) { out.unit = normaliseUnit(u[1]); tail = tail.slice(u[0].length); }

    if (!out.flag) { f = FLAG_RE.exec(tail); if (f) { out.flag = f[1].toUpperCase(); tail = tail.slice(f[0].length); } }

    var r = RANGE_RE.exec(tail);
    if (r) { out.low = toNum(r[1]); out.high = toNum(r[2]); }
    else {
      var o = ONE_SIDED_RE.exec(tail);
      if (o) { if (o[1].charAt(0) === '<') out.high = toNum(o[2]); else out.low = toNum(o[2]); }
    }
    if (!out.flag) { f = /(?:^|\s)(HH|LL|H|L)(?=\s|$)/.exec(tail); if (f) out.flag = f[1]; }
    return out;
  }

  function status(row) {
    if (row.value == null) return 'unknown';
    if (row.low != null && row.value < row.low) return 'below';
    if (row.high != null && row.value > row.high) return 'above';
    if (row.low == null && row.high == null) return 'no-range';
    return 'within';
  }

  function confidence(row) {
    var score = 0;
    if (row.key) score += 2;
    if (row.value != null) score += 2;
    if (row.unit) score += 1;
    if (row.low != null || row.high != null) score += 1;
    if (row.notes.length) score -= 1;
    if (score >= 6) return 'high';
    if (score >= 4) return 'medium';
    return 'low';
  }

  function parseText(text) {
    var rawLines = String(text || '').split(/\r?\n/);
    var lines = [];
    var dropped = 0;
    rawLines.forEach(function (l) {
      l = normaliseLine(l);
      if (!l) return;
      if (PII_RE.test(l)) { dropped++; return; }
      l = normaliseLine(l.replace(DATE_RE, ' '));
      if (l) lines.push(l);
    });

    // Join "name on one line, number on the next" layouts.
    var joined = [];
    for (var i = 0; i < lines.length; i++) {
      var l = lines[i];
      var hasNum = /\d/.test(l);
      var next = lines[i + 1];
      if (!hasNum && next && /^\s*[<>]?\s*\d/.test(next) && l.length <= 40) {
        joined.push(l + '  ' + next); i++;
      } else joined.push(l);
    }

    var rows = [];
    var seen = {};
    joined.forEach(function (line) {
      var hit = null, idx = -1, end = 0;
      for (var a = 0; a < ALIAS_INDEX.length; a++) {
        var e = ALIAS_INDEX[a];
        var m = e.startRe.exec(line);
        if (m) { hit = e; idx = 0; end = m[0].length; break; }
      }
      if (!hit) {
        for (var b = 0; b < ALIAS_INDEX.length; b++) {
          var e2 = ALIAS_INDEX[b];
          if (!e2.anyRe) continue;
          var m2 = e2.anyRe.exec(line);
          if (m2 && /\d/.test(line.slice(m2.index + m2[0].length))) { hit = e2; idx = m2.index; end = m2.index + m2[0].length; break; }
        }
      }

      var row;
      if (hit) {
        var tail = parseTail(line.slice(end));
        if (tail.value == null) return;
        row = {
          key: hit.marker.key, name: hit.marker.name, value: tail.value, prefix: tail.prefix,
          unit: tail.unit, low: tail.low, high: tail.high, flag: tail.flag, notes: [], source: line
        };
        if (tail.unit && !unitExpected(hit.marker, tail.unit)) row.notes.push('Unusual unit for this marker - please check');
        if (!tail.unit) row.notes.push('No unit found');
        if (tail.low == null && tail.high == null) row.notes.push('No reference range found');
      } else {
        // Unrecognised marker: "Some name  12.3  unit  1.0 - 5.0"
        var g = /^([A-Za-z][A-Za-z0-9 ,.\-\/()%]{2,40}?)\s{2,}([<>]?\s*\d.*)$/.exec(line) || /^([A-Za-z][A-Za-z ,.\-\/()%]{2,40}?)\s+([<>]?\s*\d+(?:[.,]\d+)?\s+\S.*)$/.exec(line);
        if (!g) return;
        var t2 = parseTail(g[2]);
        if (t2.value == null) return;
        var realUnit = t2.unit && REAL_UNIT_RE.test(t2.unit);
        if (!realUnit && t2.low == null && t2.high == null) return;
        var nm = g[1].replace(/[\s:.\-]+$/, '').trim();
        if (!/[a-z]/i.test(nm) || /\b(page|total|result|test|date|time|collected|received|reported|comment|note|lab|site)\b/i.test(nm)) return;
        row = { key: '', name: nm, value: t2.value, prefix: t2.prefix, unit: t2.unit, low: t2.low, high: t2.high, flag: t2.flag, notes: ['Marker not recognised - check the name'], source: line };
      }
      var dedupe = row.key || row.name.toLowerCase();
      if (seen[dedupe]) return;
      seen[dedupe] = true;
      row.status = status(row);
      row.confidence = confidence(row);
      rows.push(row);
    });

    return { rows: rows, droppedLines: dropped, totalLines: rawLines.length };
  }

  // What would leave the device in the real service: numbers only.
  function buildPayload(rows) {
    return {
      schema: 'labwise.values.v0',
      note: 'Confirmed by the user in the browser. No file, no name, no dates.',
      markers: rows.filter(function (r) { return r.value != null && r.name; }).map(function (r) {
        var o = { name: r.name, value: r.value };
        if (r.key) o.key = r.key;
        if (r.prefix) o.qualifier = r.prefix;
        if (r.unit) o.unit = r.unit;
        if (r.low != null) o.ref_low = r.low;
        if (r.high != null) o.ref_high = r.high;
        return o;
      })
    };
  }

  var SAMPLE_TEXT = [
    'SYNTHETIC SAMPLE REPORT - NOT A REAL PATIENT',
    'Patient Name: Sample, Test     DOB: 1980-01-01     Health Card: 0000-000-000',
    'Collected: 2026-10-01 08:15     Reported: 2026-10-02',
    '',
    'HEMATOLOGY',
    'Hemoglobin           142      g/L         135 - 175',
    'Hematocrit           0.42     L/L         0.40 - 0.50',
    'RBC                  4.8      x10*12/L    4.5 - 6.0',
    'WBC                  6.1      x10*9/L     4.0 - 11.0',
    'Platelets            255      x10*9/L     150 - 400',
    'MCV                  88       fL          80 - 100',
    'Ferritin             18   L   ug/L        30 - 400',
    '',
    'CHEMISTRY',
    'Glucose Fasting      5.9  H   mmol/L      3.6 - 5.5',
    'Hemoglobin A1c       5.8      %           4.0 - 6.0',
    'Creatinine           82       umol/L      60 - 110',
    'eGFR                 95       mL/min/1.73m2   >60',
    'Sodium               140      mmol/L      135 - 145',
    'Potassium            4.2      mmol/L      3.5 - 5.0',
    'ALT                  31       U/L         <50',
    'TSH                  2.1      mIU/L       0.32 - 4.00',
    'Vitamin D (25-OH)    58   L   nmol/L      75 - 250',
    'Total Cholesterol    5.4  H   mmol/L      <5.2',
    'LDL Cholesterol      3.4      mmol/L      <3.5',
    'HDL Cholesterol      1.3      mmol/L      >1.0',
    'Triglycerides        1.5      mmol/L      <1.7',
    'Osmolality           290      mmol/kg     275 - 295',
    '',
    'Page 1 of 1'
  ].join('\n');

  global.LabParse = {
    MARKERS: MARKERS,
    parseText: parseText,
    buildPayload: buildPayload,
    status: status,
    SAMPLE_TEXT: SAMPLE_TEXT
  };
})(window);
